# 读取数据并进行基本分析

# 载入需要的包
library(ggplot2)

# 读取学生数据
students <- read.table("data/account.txt", header=TRUE, sep="\t")
# 将学生学号转为因子
students$studentcode <- factor(students$studentcode)
# 统计校园卡总数
numOfCard <- length(unique(students$account))
# 统计唯一的学生学号数（有部分学生有两张校园卡纪录）
numOfUniqueID <- length(unique(students$studentcode))
# 绘图部分
p <- ggplot(students) + geom_histogram(aes(x=yearofbirth, fill=gender)) + facet_wrap(~type) + labs(x="出生年份", y="用户数量", title="用户类别、性别和出生年份分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), plot.title=element_text(vjust=1.2), legend.title=element_blank(), strip.text=element_text(size=12))
plot(p)

# 读取商户数据
merchants <- read.table("data/merchant.txt", header=TRUE, sep="\t")
# 将syscode和toaccount转为因子
merchants$syscode <- factor(merchants$syscode)
merchants$toaccount <- factor(merchants$toaccount)
# 将address为空的标记为NA
merchants$address[merchants$address == ""] <- NA
# 商户系统个数
numOfSys <- length(unique(merchants$syscode))
# 子商户账号个数
numOfToAccount <- length(unique(merchants$toaccount))
# 绘图部分
p <- ggplot(merchants, aes(x=codename), stat="identity") + geom_bar( fill="pink") + labs(x="商户系统名称", y="子商户数量", title="商户系统分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title=element_text(size=15), axis.text.x=element_text(angle=70, size=12, vjust=0.5), plot.title=element_text(size=18, vjust=1.5), axis.title.y=element_text(vjust=0.8))
plot(p)

# 读取交易数据
trades <- read.table("data/trade.txt", header=TRUE, sep="\t")
# 将fromaccount、toaccount、syscode转为因子
trades$fromaccount <- factor(trades$fromaccount)
trades$toaccount <- factor(trades$toaccount)
trades$syscode <- factor(trades$syscode)
# 将交易金额为非正数的记录标记为NA
trades$amount[trades$amount <= 0] <- NA
# 计算有效和无效的交易记录数
numOfValidTrade <- sum(complete.cases(trades))
numOfInvalidTrade <- sum(!complete.cases(trades))
# 清除NA记录
trades <- trades[complete.cases(trades),]
# 将交易金额从“分”改为“元”
trades$amount <- trades$amount / 100

# 读取气象数据
weather <- read.table("data/weather.txt", header=TRUE, sep="\t")
weather <- weather[,c(1, 4)]
names(weather) <- c("timestamp", "rain")
weather$rain[weather$rain == "////"] <- NA
weather <- weather[complete.cases(weather),]
weather$timestamp <- as.character(weather$timestamp)
weatherStat <- weather
weatherStat$timestamp <- as.Date(weatherStat$timestamp, "%Y%m%d")
weatherDaily <- aggregate(weatherStat$rain ~ weatherStat$timestamp, FUN=mean)
names(weatherDaily) <- c("timestamp", "rain")
rm(weatherStat)
weather$timestamp <- as.POSIXct(weather$timestamp, format="%Y%m%d%H%M")
# 绘图 雨量分布密度图
p <- ggplot(weatherDaily, aes(x=timestamp, y=rain)) + geom_bar(stat="identity") + labs(x="日期", y="日均降雨量", title="历史降雨量") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title=element_text(size=12), plot.title=element_text(vjust=1.2, size=15))
plot(p)

# 读取网络流量数据
traffic <- read.table("data/traffic.txt", header=FALSE, sep="\t")
names(traffic) <- c("id", "timestamp")
traffic$timestamp <- traffic$timestamp / 1000
traffic$timestamp <- floor(traffic$timestamp)
traffic$timestamp <- as.POSIXct(traffic$timestamp, origin = "1970-01-01")
traffic$timestamp <- as.Date(traffic$timestamp, format="%Y-%m-d%")
traffic <- traffic[!duplicated(traffic),]

# 统计每天活跃的用户数量
dailyActiveStudents <- as.data.frame(table(traffic$timestamp))
rm(traffic)
names(dailyActiveStudents) <- c("timestamp", "freq")
dailyActiveStudents$timestamp <- as.Date(dailyActiveStudents$timestamp, format="%Y-%m-%d")
dailyActiveStudents <- dailyActiveStudents[dailyActiveStudents$timestamp > "2014-08-31",]
dailyActiveStudents <- dailyActiveStudents[dailyActiveStudents$timestamp < "2015-02-01",]
p <- ggplot(dailyActiveStudents, aes(x=timestamp, y=freq)) + geom_point() + stat_smooth() + geom_line(alpha=0.4) + labs(x="日期", y="日均活跃用户", title="校园网日均活跃用户数量") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title=element_text(size=12), plot.title=element_text(vjust=1.2, size=15))
plot(p)

rm(p)