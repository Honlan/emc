#!/usr/bin/env python
# coding:utf8
import time

def pair(x, y):
	if x > y:
		return str(x) + '_' + str(y)
	else:
		return str(y) + '_' + str(x)

ISOTIMEFORMAT='%Y-%m-%d %X'

inputFile = 'sancan.txt'
fr = open(inputFile,'r')

# outputFile = "node.txt"
# fw1 = open(outputFile,'w')

outputFile = "link.txt"
fw2 = open(outputFile,'w')

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

records = []
pairs = {}

for line in fr:
	records.append(line)

N = len(records)

for i in xrange(0, N):
	print i
	for j in xrange(i + 1, N):
		record1 = records[i].split(',')
		record2 = records[j].split(',')
		
		account1 = record1[0]
		timestamp1 = time.mktime(time.strptime(record1[1],'%Y-%m-%d %H:%M:%S'))
		amount1 = record1[2]
		gender1 = record1[3]
		major1 = record1[4].strip('\n')

		account2 = record2[0]
		timestamp2 = time.mktime(time.strptime(record2[1],'%Y-%m-%d %H:%M:%S'))
		amount2 = record2[2]
		gender2 = record2[3]
		major2 = record2[4].strip('\n')

		if timestamp2 - timestamp1 <= 60 * 3:
			if pairs.has_key(pair(account1,account2)):
				pairs[pair(account1,account2)] = pairs[pair(account1,account2)] + 1
			else:
				pairs[pair(account1,account2)] = 1
		else:
			break

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

for (key, value) in pairs.items():
	if value >= 10:
		fw2.write(key.split('_')[0] + '\t' + key.split('_')[1] + '\t' + str(value) + '\n')

fr.close()
fw2.close()
