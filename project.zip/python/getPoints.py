#!/usr/bin/env python
# coding:utf8
import time
import json

ISOTIMEFORMAT='%Y-%m-%d %X'

inputFile = 'sancan.txt'
fr = open(inputFile,'r')

outputFile = "link.json"
fw = open(outputFile,'w')

print time.strftime( ISOTIMEFORMAT, time.localtime() )

persons = {}

for line in fr:
	line = line.split(',')
	account = line[0]
	gender = line[3]
	major = line[4].strip('\n')
	if persons.has_key(account):
		pass
	else:
		persons[account] = gender + '_' + major

print time.strftime( ISOTIMEFORMAT, time.localtime() )

fr.close()

inputFile = 'link.txt'
fr = open(inputFile,'r')

resultJson = {}

nodes = {}

count = 0

for line in fr:
	line = line.split('\t')
	source = line[0]
	target = line[1]

	if nodes.has_key(source):
		pass
	else:
		nodes[source] = count
		count = count + 1
	if nodes.has_key(target):
		pass
	else:
		nodes[target] = count
		count = count + 1

print time.strftime( ISOTIMEFORMAT, time.localtime() )

tmp = []

for k in nodes.keys():
	t = {}
	v = persons[k]
	if v.split('_')[0] == "男" and v.split('_')[1] == "本科":
		t['name'] = k
		t['group'] = 1
		tmp.append(t)
	elif v.split('_')[0] == "男" and v.split('_')[1] == "硕士":
		t['name'] = k
		t['group'] = 2
		tmp.append(t)
	elif v.split('_')[0] == "男" and v.split('_')[1] == "博士":
		t['name'] = k
		t['group'] = 3
		tmp.append(t)
	elif v.split('_')[0] == "女" and v.split('_')[1] == "本科":
		t['name'] = k
		t['group'] = 4
		tmp.append(t)
	elif v.split('_')[0] == "女" and v.split('_')[1] == "硕士":
		t['name'] = k
		t['group'] = 5
		tmp.append(t)
	elif v.split('_')[0] == "女" and v.split('_')[1] == "博士":
		t['name'] = k
		t['group'] = 6
		tmp.append(t)

resultJson['nodes'] = tmp

fr.close()

inputFile = 'link.txt'
fr = open(inputFile,'r')

tmp = []

for line in fr:
	line = line.split('\t')
	source = line[0]
	target = line[1]
	size = line[2].strip('\n')
	t = {}
	t['source'] = nodes[source]
	t['target'] = nodes[target]
	t['value'] = int(size)
	tmp.append(t)

resultJson['links'] = tmp

fr.close()

json.dump(resultJson, fw)

fw.close()