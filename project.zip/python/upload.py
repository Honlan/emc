# coding:utf8
import time
# import datetime
import urllib2
import urllib

ISOTIMEFORMAT='%Y-%m-%d %X'

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

students = ['A47544', 'A51811', 'A74351', 'B61142', 'B72486', 'C56309', 'C56623', 'C59334', 'C63500', 'C74610', 'D55953', 'D60394', 'D60662', 'D65381', 'E70263']

for person in students:
	
	inputFile = 'grafana/tradeMe.txt'
	fr = open(inputFile,'r')

	data_head = '[{"name": "' + person + '", "columns": ["time", "sequence_number", "amount"],"points":['
	data_tail = ']}]'
	data_body = ''
	subcount = 0
	print person

	for line in fr:
		line = line.split(',')
		if line[0] == person:
			subcount = subcount + 1
			timestamp = line[1]
			amount = line[2].rstrip('\n')
			timestamp = time.mktime(time.strptime(timestamp,'%Y-%m-%d %H:%M:%S'))
			timestamp = int(timestamp * 1000)
			data_body += '['+str(timestamp)+', '+str(subcount)+', '+str(amount)+'],'

	print subcount
	response = urllib2.urlopen('http://localhost:8086/db/emc/series?u=root&p=root', data_head+data_body[:-1]+data_tail)
	data_body = ''
	fr.close()

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )