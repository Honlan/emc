#!/usr/bin/env python
# coding:utf8
import time

ISOTIMEFORMAT='%Y-%m-%d %X'

inputFile = 'data/net_traffic.txt'
fr = open(inputFile,'r')

outputFile = "data/traffic.txt"
fw = open(outputFile,'w')

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

count = 0

for line in fr:
	line = line.split(",")
	record = line[0] + '\t' + line[2] + '\n'
	fw.write(record)
	count = count + 1

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

print count

fr.close()
fw.close()
