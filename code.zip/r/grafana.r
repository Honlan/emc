# 导出数据至influxdb
tradeBestMerchant <- trades[trades$toaccount == "1000233",]
write.table(tradeBestMerchant[,c("amount","timestamp")], file = "bestMerchant.txt",sep = ",", col.names = NA)
write.table(tradeMe[,c("account", "timestamp", "amount")], file = "tradeMe.txt",sep = ",", col.names = NA)
write.table(weather, file = "weather.txt",sep = ",", col.names = NA)
write.table(dailyActiveStudents, file = "daily.txt",sep = ",", col.names = NA)