# 详细分析销售额排名第一的商户
# 地图形势展示交易次数排名前五的商户

# 首先详细分析交易总额排名第一的商户 1000233 3793804 新闵行第三食堂 闵行第三餐饮学生餐厅
# 获取该商户2014.09.01~2015.01.31全部交易数据
bestMerchant <- trades[trades$toaccount == "1000233",]

# 获取10.30和10.23的详细数据，进行天气关联分析
bestMerchantWithRain <- bestMerchant[as.Date(bestMerchant$timestamp, "%Y-%m-%d") == "2014-11-25",]
bestMerchantWithoutRain <- bestMerchant[as.Date(bestMerchant$timestamp, "%Y-%m-%d") == "2014-11-18",]
#bestMerchantWithRain <- bestMerchantWithRain[, c("timestamp", "amount")]
#bestMerchantWithoutRain <- bestMerchantWithoutRain[, c("timestamp", "amount")]
bestMerchantWithRain$rain <- "有雨"
bestMerchantWithoutRain$rain <- "无雨"
bestMerchantWithRain$timestamp <- as.POSIXct(bestMerchantWithRain$timestamp, format="%Y-%m-%d %H:%M:%S")
bestMerchantWithoutRain$timestamp <- as.POSIXct(bestMerchantWithoutRain$timestamp, format="%Y-%m-%d %H:%M:%S")  
bestMerchantRain <- rbind(bestMerchantWithoutRain,bestMerchantWithRain)
rm(bestMerchantWithRain)
rm(bestMerchantWithoutRain)

# 绘图 有雨和无雨的消费记录
p <- ggplot(bestMerchantRain[bestMerchantRain$rain=="有雨",], aes(timestamp, amount))+ stat_density2d(aes(fill = ..level..), geom="polygon") + scale_fill_continuous(high='darkblue',low='white') + labs(x="当日时间", y="每次消费额度/元", title="11/25(有雨)闵行第三餐饮学生餐厅消费分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title=element_text(size=12), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank())
plot(p)
p <- ggplot(bestMerchantRain[bestMerchantRain$rain=="无雨",], aes(timestamp, amount))+ stat_density2d(aes(fill = ..level..), geom="polygon") + scale_fill_continuous(high='darkblue',low='white') + labs(x="当日时间", y="每次消费额度/元", title="11/18(无雨)闵行第三餐饮学生餐厅消费分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title=element_text(size=12), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank())
plot(p)
p <- ggplot(bestMerchantRain[bestMerchantRain$rain=="有雨",]) + geom_point(aes(x=timestamp, y=amount, colour=type)) + scale_y_continuous(limits=c(0,20)) + labs(x="当日时间", y="每次消费额度/元", title="11/25(有雨)闵行第三餐饮学生餐厅消费散点图") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title=element_text(size=12), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank())
plot(p)
p <- ggplot(bestMerchantRain[bestMerchantRain$rain=="无雨",]) + geom_point(aes(x=timestamp, y=amount, colour=type)) + scale_y_continuous(limits=c(0,20)) + labs(x="当日时间", y="每次消费额度/元", title="11/18(无雨)闵行第三餐饮学生餐厅消费散点图") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title=element_text(size=12), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank())
plot(p)


# 统计每天的交易总额
bestMerchant$timestamp <- as.Date(bestMerchant$timestamp, "%Y-%m-%d")
bestMerchant <- aggregate(bestMerchant$amount ~ bestMerchant$timestamp, FUN=sum)
names(bestMerchant) <- c("timestamp", "sum") 

# 绘图 每天交易总额走势，包括雨量分布、在校学生人数
start <- as.Date(c("2014-09-01", "2014-09-06", "2014-09-08", "2014-09-13", "2014-09-15", "2014-09-20", "2014-09-22", "2014-09-27", "2014-09-29", "2014-10-04", "2014-10-06", "2014-10-11", "2014-10-13", "2014-10-18", "2014-10-20", "2014-10-25", "2014-10-27", "2014-11-01", "2014-11-03", "2014-11-08", "2014-11-10", "2014-11-15", "2014-11-17", "2014-11-22", "2014-11-24", "2014-11-29", "2014-12-01", "2014-12-06", "2014-12-08", "2014-12-13", "2014-12-15", "2014-12-20", "2014-12-22", "2014-12-27", "2014-12-29", "2015-01-03", "2015-01-05", "2015-01-10", "2015-01-12", "2015-01-17", "2015-01-19", "2015-01-24", "2015-01-26", "2015-01-31"))
end <- as.Date(c("2014-09-06", "2014-09-08", "2014-09-13", "2014-09-15", "2014-09-20", "2014-09-22", "2014-09-27", "2014-09-29", "2014-10-04", "2014-10-06", "2014-10-11", "2014-10-13", "2014-10-18", "2014-10-20", "2014-10-25", "2014-10-27", "2014-11-01", "2014-11-03", "2014-11-08", "2014-11-10", "2014-11-15", "2014-11-17", "2014-11-22", "2014-11-24", "2014-11-29", "2014-12-01", "2014-12-06", "2014-12-08", "2014-12-13", "2014-12-15", "2014-12-20", "2014-12-22", "2014-12-27", "2014-12-29", "2015-01-03", "2015-01-05", "2015-01-10", "2015-01-12", "2015-01-17", "2015-01-19", "2015-01-24", "2015-01-26", "2015-01-31", "2015-02-02"))
days <- rep(c("工作日", "周末"), 22)
calendar <- data.frame(start=start, end=end, day=days)
rm(start)
rm(end)
rm(days)
p <- ggplot(bestMerchant) + geom_point(aes(x=timestamp, y=sum), shape=19) + geom_line(aes(x=timestamp, y=sum), alpha=0.5) + stat_smooth(aes(x=timestamp, y=sum), colour="slateblue4") + labs(x="时间(2014/09/01~2015/01/31)", y="日消费总额/元", title="闵行第三餐饮学生餐厅日消费总额历史数据") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=-0.1, size=15), axis.title.y=element_text(vjust=1, size=15), axis.text.x=element_text(size=12), plot.title=element_text(vjust=1.5, size=18), legend.title=element_blank()) + geom_rect(aes(NULL, NULL, xmin=start, xmax=end, fill=day), ymin=range(bestMerchant$sum)[1], ymax=range(bestMerchant$sum)[2], data = calendar, alpha=0.2) + scale_fill_manual(values = c('red','white')) + geom_line(data=weatherDaily[weatherDaily$timestamp > "2014-09-30" & weatherDaily$timestamp < "2015-02-01",], aes(x=timestamp, y=rain*15000), alpha=0.9, colour="cadetblue3") + geom_line(aes(x=timestamp, y=freq), data=dailyActiveStudents[dailyActiveStudents$timestamp > "2014-09-09" & dailyActiveStudents$timestamp < "2015-02-01", ], alpha="0.6", colour="chartreuse4")
plot(p)

# 导出消费次数前五名的数据做地图展示
mapData <- trades[trades$toaccount %in% c("1000233", "1000027", "1000091", "1000093", "1000001"),]
mapData <- mapData[,c("toaccount", "timestamp")]
# 仅展示10月28日的数据
mapData <- mapData[as.Date(mapData$timestamp, format="%Y-%m-%d")=="2014-10-28",]
write.table(mapData, file = "map.txt",sep = ",", col.names = NA)

rm(p)