#分析商户数据

library(RColorBrewer)
library(wordcloud)

# 整合trades以加入每条消费记录的用户gender和type
names(trades)[1] <- "account"
trades <- merge(trades, students[,c("account","gender","type")], all.x=TRUE, all.y=FALSE)

# 根据toaccount得到商户系统统计数据
merchantMean <- aggregate(trades$amount ~ trades$toaccount + trades$gender + trades$type, FUN=mean)
names(merchantMean) <- c("account", "gender", "type", "mean")
merchantSum <- aggregate(trades$amount ~ trades$toaccount + trades$gender + trades$type, FUN=sum)
names(merchantSum) <- c("account", "gender", "type", "sum")
merchantStat <- merchantSum
merchantStat$mean <- merchantMean$mean
merchantStat$count <- merchantStat$sum / merchantStat$mean
rm(merchantMean)
rm(merchantSum)
# 将codename、syscode、accountname整合至merchantStat
tmp <- merchants[, c("toaccount", "codename", "accountname", "syscode")]
names(tmp)[1] <- "account"
tmp <- tmp[!duplicated(tmp$account),]

# 计算各项top10
merchantGenderSum <- aggregate(merchantStat$sum ~ merchantStat$account + merchantStat$gender, FUN=sum)
merchantGenderCount <- aggregate(merchantStat$count ~ merchantStat$account + merchantStat$gender, FUN=sum)
names(merchantGenderSum) <- c("account", "gender", "sum")
names(merchantGenderCount) <- c("account", "gender", "count")
merchantGender <- merchantGenderSum
merchantGender$count <- merchantGenderCount$count
rm(merchantGenderSum)
rm(merchantGenderCount)
merchantGender <- merge(merchantGender, tmp, all.x=TRUE, all.y=FALSE)
merchantBoy <- merchantGender[merchantGender$gender=="男",]
merchantGirl <- merchantGender[merchantGender$gender=="女",]
topCountBoy <- merchantBoy[order(-merchantBoy$count)[1:10], c("account", "count", "codename", "accountname", "syscode")]
topCountGirl <- merchantGirl[order(-merchantGirl$count)[1:10], c("account", "count", "codename", "accountname", "syscode")]
rm(merchantBoy)
rm(merchantGirl)
rm(merchantGender)
merchantWithoutTGSum <- aggregate(merchantStat$sum ~ merchantStat$account, FUN=sum)
merchantWithoutTGCount <- aggregate(merchantStat$count ~ merchantStat$account, FUN=sum)
names(merchantWithoutTGSum) <- c("account", "sum")
names(merchantWithoutTGCount) <- c("account", "count")
merchantWithoutTG <- merchantWithoutTGSum
merchantWithoutTG$count <- merchantWithoutTGCount$count
rm(merchantWithoutTGSum)
rm(merchantWithoutTGCount)
merchantWithoutTG$mean <- merchantWithoutTG$sum / merchantWithoutTG$count
merchantWithoutTG <- merge(merchantWithoutTG, tmp, all.x=TRUE, all.y=FALSE)
topCount <- merchantWithoutTG[order(-merchantWithoutTG$count)[1:10], c("account", "count", "codename", "accountname", "syscode")]
topSale <- merchantWithoutTG[order(-merchantWithoutTG$sum)[1:10], c("account", "sum", "codename", "accountname", "syscode")]
topCheap <- merchantWithoutTG[order(merchantWithoutTG$mean)[1:10], c("account", "mean", "codename", "accountname", "syscode")]
topExpensive <- merchantWithoutTG[order(-merchantWithoutTG$mean)[1:10], c("account", "mean", "codename", "accountname", "syscode")]

# 按消费类型统计消费分布
tmp$class <- c("就餐","就餐","点心","就餐","点心","点心","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","就餐","就餐","用水","用水","用水","用水","图书","校车","就餐","超市","就餐","就餐","学务","就餐","就餐","图书","超市","就餐","就餐","水果","咖啡","就餐","就餐","咖啡","就餐","就餐","就餐","就餐","就餐","点心","点心","活动","活动","活动","活动","活动","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","活动","图书","水果","活动","就餐","水果","咖啡","点心") 
tmp$class <- factor(tmp$class)
merchantStat <- merge(merchantStat, tmp, all.x=TRUE, all.y=FALSE)
rm(tmp)
# 绘图 各个子商户的统计结果
tmp <- merchantWithoutTG[order(-merchantWithoutTG$sum)[1:40],]$account
tmp <- merchantStat[merchantStat$account %in% tmp,]
tmpMan <- tmp[tmp$gender=="男",]
tmpWoman <- tmp[tmp$gender=="女",]
tmpMan <- tmpMan[,c("type", "accountname", "sum")]
tmpMan$sum[tmpMan$accountname=="教育超市" & tmpMan$type=="博士"] <- 58043.24
tmpMan$sum[tmpMan$accountname=="教育超市" & tmpMan$type=="硕士"] <- 290209.36
tmpMan$sum[tmpMan$accountname=="教育超市" & tmpMan$type=="本科"] <- 1044654.37
tmpWoman <- tmpWoman[,c("type", "accountname", "sum")]
tmpWoman$sum[tmpWoman$accountname=="教育超市" & tmpWoman$type=="博士"] <- 35513.5
tmpWoman$sum[tmpWoman$accountname=="教育超市" & tmpWoman$type=="硕士"] <- 121612.09
tmpWoman$sum[tmpWoman$accountname=="教育超市" & tmpWoman$type=="本科"] <- 509655.94
tmpMan <- tmpMan[!duplicated(tmpMan),]
tmpWoman <- tmpWoman[!duplicated(tmpWoman),]
tmpMan$type <- factor(tmpMan$type, ordered=TRUE, levels=c("本科", "硕士", "博士"))
tmpMan <- tmpMan[order(tmpMan$type),]
tmpWoman$type <- factor(tmpWoman$type, ordered=TRUE, levels=c("本科", "硕士", "博士"))
tmpWoman <- tmpWoman[order(tmpWoman$type),]
rm(tmp)

p <- ggplot(tmpMan) + geom_bar(aes(x=accountname, y=sum, fill=type), stat="identity") + labs(x="子商户名称", y="消费总额", title="男生在各子商户消费总额分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.5), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), strip.text=element_text(size=12),axis.text.x=element_text(size=12, angle=70, vjust=0.5), axis.title=element_text(size=12))
plot(p)
p <- ggplot(tmpWoman) + geom_bar(aes(x=accountname, y=sum, fill=type), stat="identity") + labs(x="子商户名称", y="消费总额", title="女生在各子商户消费总额分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.5), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), strip.text=element_text(size=12),axis.text.x=element_text(size=12, angle=70, vjust=0.5), axis.title=element_text(size=12))
plot(p)

rm(tmpMan)
rm(tmpWoman)


# 计算各个消费类别的统计数据
classSum <- aggregate(merchantStat$sum ~ merchantStat$gender + merchantStat$type + merchantStat$class, FUN=sum)
names(classSum) <- c("gender", "type", "class", "sum")
classCount <- aggregate(merchantStat$count ~ merchantStat$gender + merchantStat$type + merchantStat$class, FUN=sum)
names(classCount) <- c("gender", "type", "class", "count")
classStat <- merge(classSum, classCount)
classStat$mean <- classStat$sum / classStat$count
rm(classCount)
rm(classSum)

# 绘图部分
## 绘图，一卡通数据消费总额分布
p <- ggplot(classStat) + geom_bar(aes(x=class,y=sum,fill=gender), stat="identity") + facet_wrap(~type) + labs(x="消费分类", y="消费总额/元", title="一卡通消费总额分布") + theme(text=element_text(family="Microsoft YaHei"), legend.title=element_blank(), axis.title.x=element_text(vjust=-0.1, size=15), axis.title.y=element_text(vjust=1, size=15), axis.text.x=element_text(size=12), plot.title=element_text(vjust=1.5, size=18))
plot(p)
## 绘图，一卡通数据消费次数分布
p <- ggplot(classStat) + geom_bar(aes(x=class,y=count,fill=gender), stat="identity") + facet_wrap(~type) + labs(x="消费分类", y="消费次数", title="一卡通消费次数统计") + theme(text=element_text(family="Microsoft YaHei"), legend.title=element_blank(), axis.title.x=element_text(vjust=-0.1, size=15), axis.title.y=element_text(vjust=1, size=15), axis.text.x=element_text(size=12), plot.title=element_text(vjust=1.5, size=18))
plot(p)
## 绘图，一卡通数据消费均值分布
p <- ggplot(classStat) + geom_bar(aes(x=class,y=mean,fill=gender), stat="identity") + facet_wrap(~type) + labs(x="消费分类", y="消费均额/元", title="一卡通消费均额统计") + theme(text=element_text(family="Microsoft YaHei"), legend.title=element_blank(), axis.title.x=element_text(vjust=-0.1, size=15), axis.title.y=element_text(vjust=1, size=15), axis.text.x=element_text(size=12), plot.title=element_text(vjust=1.5, size=18))
plot(p)

## 根据消费次数绘制标签云
p <- wordcloud(merchantWithoutTG$accountname, merchantWithoutTG$count, scale=c(6, 0.5), min.freq=1, max.words=Inf, colors=brewer.pal(12,"Paired"), family="Microsoft YaHei")
plot(p)

rm(p)