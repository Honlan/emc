library(dplyr)
library(tidyr)

# 分析学生数据

# 将codename、syscode、accountname整合至trades
tmp <- merchants[, c("toaccount", "codename", "accountname")]
tmp <- tmp[!duplicated(tmp$toaccount),]
tmp$class <- c("就餐","就餐","点心","就餐","点心","点心","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","就餐","就餐","用水","用水","用水","用水","图书","校车","就餐","超市","就餐","就餐","学务","就餐","就餐","图书","超市","就餐","就餐","水果","咖啡","就餐","就餐","咖啡","就餐","就餐","就餐","就餐","就餐","点心","点心","活动","活动","活动","活动","活动","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","活动","图书","水果","活动","就餐","水果","咖啡","点心") 
tmp$class <- factor(tmp$class)
tradeFull <- merge(trades, tmp, all.x=TRUE, all.y=FALSE)
rm(tmp)
# 从30861个用户中抽取2000个样本，1000个用于分析，另外1000个用于检验
set.seed(2015)
studentSampleData <- students[sample(1:nrow(students), 2000, replace=FALSE),]
studentTestData <- studentSampleData[c(1001:2000),]
studentSampleData <- studentSampleData[c(1:1000),]
# 获取对应的交易数据
tradeSampleData <- tradeFull[tradeFull$account %in% studentSampleData$account,]
tradeTestData <- tradeFull[tradeFull$account %in% studentTestData$account,]
# 计算样本比例是否保持一致
genderRatio <- data.frame(table(students$gender), table(studentSampleData$gender), table(studentTestData$gender))
typeRatio <- data.frame(table(students$type), table(studentSampleData$type), table(studentTestData$type))
genderRatio <- genderRatio[,c(2,4,6)]
typeRatio <- typeRatio[,c(2,4,6)]
names(genderRatio) <- c("Full", "Sample", "Test")
names(typeRatio) <- c("Full", "Sample", "Test")
row.names(genderRatio) <- c("男", "女")
row.names(typeRatio) <- c("本科", "博士", "硕士")
genderRatio$Full <- genderRatio$Full / sum(genderRatio$Full)
genderRatio$Sample <- genderRatio$Sample / sum(genderRatio$Sample)
genderRatio$Test <- genderRatio$Test / sum(genderRatio$Test)
typeRatio$Full <- typeRatio$Full / sum(typeRatio$Full)
typeRatio$Sample <- typeRatio$Sample / sum(typeRatio$Sample)
typeRatio$Test <- typeRatio$Test / sum(typeRatio$Test)
sampleRatio <- rbind(genderRatio, typeRatio)
rm(typeRatio)
rm(genderRatio)
# 对于样本数据，计算每名用户在各类消费的消费次数和消费总额
studentSampleSum <- aggregate(tradeSampleData$amount ~ tradeSampleData$account + tradeSampleData$class, FUN=sum)
studentSampleMean <- aggregate(tradeSampleData$amount ~ tradeSampleData$account + tradeSampleData$class, FUN=mean)
names(studentSampleSum) <- c("account", "class", "sum")
names(studentSampleMean) <- c("account", "class", "mean")
studentSampleStat <- studentSampleSum
studentSampleStat$mean <- studentSampleMean$mean
rm(studentSampleSum)
rm(studentSampleMean)
studentSampleStat$count <- studentSampleStat$sum / studentSampleStat$mean
# 扩充统计数据至全集，即每名用户都有10项消费数据
tmp <- merge(data.frame(account=unique(studentSampleStat$account)), data.frame(class=unique(studentSampleStat$class)))
studentSampleStat <- merge(studentSampleStat, tmp, all.y=TRUE)
rm(tmp)
studentSampleStat$sum[!complete.cases(studentSampleStat)] <- 0
studentSampleStat$count[!complete.cases(studentSampleStat)] <- 0
# 将每名用户的消费统计数据扩展进type和gender
studentSampleStat <- merge(studentSampleStat, studentSampleData[,c("account", "gender", "type")], all.x=TRUE, all.y=FALSE)
# 绘图 各人群不同分类消费的消费次数分布
p <- ggplot(studentSampleStat) + geom_boxplot(aes(x=class, y=count, colour=class)) + facet_wrap(~gender+type) + labs(x="消费分类", y="消费次数", title="用户各消费类别消费次数分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), strip.text=element_text(size=12),axis.text.x=element_text(size=10), axis.title=element_text(size=12))
plot(p)
# 绘图 各人群不同分类消费的消费总额分布
p <- ggplot(studentSampleStat) + geom_boxplot(aes(x=class, y=sum, colour=class)) + facet_wrap(~gender+type) + labs(x="消费分类", y="消费总额", title="用户各消费类别消费总额分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), strip.text=element_text(size=12),axis.text.x=element_text(size=10), axis.title=element_text(size=12))
plot(p)

# 统计每名用户的消费向量，即在各个商户的消费次数
# 仅考虑就餐记录
tmp1 <- aggregate(tradeSampleData$amount ~ tradeSampleData$account + tradeSampleData$toaccount, FUN=sum)
names(tmp1) <- c("account", "toaccount", "sum")
tmp2 <- aggregate(tradeSampleData$amount ~ tradeSampleData$account + tradeSampleData$toaccount, FUN=mean)
names(tmp2) <- c("account", "toaccount", "mean")
studentSampleVector <- tmp1
studentSampleVector$count <- tmp1$sum / tmp2$mean
studentSampleVector <- studentSampleVector[,c("account", "toaccount", "count")]
rm(tmp1)
rm(tmp2)
tmp <- merchants[, c("toaccount", "codename", "accountname")]
tmp <- tmp[!duplicated(tmp$toaccount),]
tmp$class <- c("就餐","就餐","点心","就餐","点心","点心","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","超市","就餐","就餐","就餐","就餐","就餐","就餐","用水","用水","用水","用水","图书","校车","就餐","超市","就餐","就餐","学务","就餐","就餐","图书","超市","就餐","就餐","水果","咖啡","就餐","就餐","咖啡","就餐","就餐","就餐","就餐","就餐","点心","点心","活动","活动","活动","活动","活动","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","就餐","活动","图书","水果","活动","就餐","水果","咖啡","点心") 
tmp$class <- factor(tmp$class)
tmp <- tmp[,c("toaccount", "class")]
tmp <- tmp[tmp$class=="就餐",]
tmp <- merge(studentSampleData$account, tmp$toaccount, all.x=TRUE, all.y=TRUE)
names(tmp) <- c("account", "toaccount")
studentSampleVector <- merge(studentSampleVector, tmp, all.y=TRUE)
rm(tmp)
studentSampleVector$count[is.na(studentSampleVector$count)] <- 0
tradeSampleData$week <- weekdays(as.POSIXct(tradeSampleData$timestamp))
tradeSampleWork <- tradeSampleData[tradeSampleData$week %in% c("星期一", "星期二", "星期三", "星期四", "星期五") & tradeSampleData$class=="就餐",]
tradeSampleWeek <- tradeSampleData[tradeSampleData$week %in% c("星期六", "星期日") & tradeSampleData$class=="就餐",]
tmp1 <- as.data.frame(table(tradeSampleWeek$account))
names(tmp1) <- c("account", "week")
tmp1 <- tmp1[tmp1$account %in% studentSampleData$account,]
tmp2 <- as.data.frame(table(tradeSampleWork$account))
names(tmp2) <- c("account", "work")
tmp2 <- tmp2[tmp2$account %in% studentSampleData$account,]
tmp <- merge(tmp1, tmp2 ,all.x=TRUE, all.y=TRUE)
tmp$workWeekend <- tmp$work / (tmp$work + tmp$week)
rm(tmp1)
rm(tmp2)
rm(tradeSampleWeek)
rm(tradeSampleWork)
studentSampleVector <- spread(studentSampleVector, toaccount, count)
studentSampleVector$sd <- apply(studentSampleVector[,c(2:53)], 1, sd)
studentSampleVector$sd <- studentSampleVector$sd / range(studentSampleVector$sd)[2]
studentSampleVector$total <- apply(studentSampleVector[,c(2:53)], 1, sum) 
studentSampleVector <- merge(studentSampleVector, tmp, all.x=TRUE, all.y=TRUE)
rm(tmp)
# studentSampleVector$workWeekend[is.na(studentSampleVector$workWeekend)] <- 0
studentSampleVector$favor <- apply(studentSampleVector[,c(2:53)], 1, which.max)
studentSampleVector$favor <- names(studentSampleVector)[studentSampleVector$favor + 1]
studentSampleVector$favor <- as.numeric(studentSampleVector$favor)
studentSampleVector$favor[studentSampleVector$total==0] <- 100000
studentSampleVector$favor <- factor(studentSampleVector$favor)
tmp <- merchants[, c("toaccount", "accountname")]
names(tmp)[1] <- "favor"
tmp <- tmp[!duplicated(tmp$favor),]
studentSampleVector <- merge(studentSampleVector, tmp, all.x=TRUE, all.y=FALSE)
rm(tmp)
studentSampleVector <- studentSampleVector[,c("account", "sd", "total", "week", "work", "workWeekend", "favor", "accountname")]
tmp <- studentSampleData[,c("account", "gender", "type")]
studentSampleVector <- merge(studentSampleVector, tmp, all.x=TRUE, all.y=FALSE)
rm(tmp)

# 绘图，用户消费方差和众数关系
p <- ggplot(studentSampleVector) + geom_point(aes(x=sd, y=accountname, colour=type), position = position_jitter(w = 0, h = 0.1)) + facet_wrap(~gender) + labs(y="就餐最大概率子商户", x="就餐均匀程度", title="用户就餐模式横向分析") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title.y=element_text(vjust=1), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), axis.title=element_text(size=12))
plot(p)
# 绘图，用户工作日休息日消费比和总消费次数的关系
p <- ggplot(studentSampleVector) + geom_point(aes(x=workWeekend, y=total, colour=type), position = position_jitter(w = 0, h = 0.0)) + facet_wrap(~gender) + labs(y="就餐总次数", x="工作日次数/总次数", title="用户就餐模式纵向分析") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title.y=element_text(vjust=1), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), axis.title=element_text(size=12))
plot(p)

# 找到我自己的纪录
studentMe <- students[students$gender=="男",]
studentMe <- studentMe[studentMe$yearofbirth==1992,]
studentMe <- studentMe[studentMe$grade==2014,]
studentMe <- studentMe[studentMe$typ=="博士",]
tradeMe <- tradeFull[tradeFull$account %in% studentMe$account,]
tradeMe <- tradeMe[tradeMe$class=="就餐",]
studentMeSum <- aggregate(tradeMe$amount ~ tradeMe$account + tradeMe$toaccount, FUN=sum)
names(studentMeSum) <- c("account", "toaccount", "sum")
studentMeMean <- aggregate(tradeMe$amount ~ tradeMe$account + tradeMe$toaccount, FUN=mean)
names(studentMeMean) <- c("account", "toaccount", "mean")
studentMeStat <- studentMeSum
studentMeStat$mean <- studentMeMean$mean
studentMeStat$count <- studentMeStat$sum / studentMeStat$mean
rm(studentMeSum)
rm(studentMeMean)
studentMeVector <- studentMeStat[,c("account", "toaccount", "count")]
studentMeVector <- spread(studentMeVector, toaccount, count)
studentMeVector[is.na(studentMeVector)] <- 0
studentMeVector$favor <- apply(studentMeVector[,c(2:46)], 1, FUN=which.max)
studentMeVector$favor <- names(studentMeVector)[studentMeVector$favor + 1]
studentMeVector$sd <- apply(studentMeVector[,c(2:46)], 1, FUN=sd)
studentMeVector$sd <- studentMeVector$sd / range(studentMeVector$sd)[2]
tmp <- merchants[, c("toaccount", "accountname")]
names(tmp)[1] <- "favor"
tmp <- tmp[!duplicated(tmp$favor),]
studentMeVector <- merge(studentMeVector, tmp, all.x=TRUE, all.y=FALSE)
rm(tmp)
studentMeVector <- studentMeVector[,c("account", "accountname", "sd")]
studentMeVector <- studentMeVector[studentMeVector$accountname=="闵行第三餐饮学生餐厅",]
studentMe <- studentMe[studentMe$account %in% studentMeVector$account,]
studentMeStat <- studentMeStat[studentMeStat$account %in% studentMe$account,]
tmp1 <- aggregate(studentMeStat$sum ~ studentMeStat$account, FUN=sum)
tmp2 <- aggregate(studentMeStat$count ~ studentMeStat$account, FUN=sum)
names(tmp1) <- c("account", "sum")
names(tmp2) <- c("account", "count")
studentMeStat <- tmp1
studentMeStat$count <- tmp2$count
studentMeStat$mean <- studentMeStat$sum / studentMeStat$count
rm(tmp1)
rm(tmp2)
tradeMe <- tradeFull[tradeFull$account %in% studentMe$account,]
classMeStat <- aggregate(tradeMe$amount ~ tradeMe$account + tradeMe$class, FUN=sum)
names(classMeStat) <- c("account", "class", "sum")
# 绘图查看消费分布
p <- ggplot(classMeStat) + geom_bar(aes(x=account, y=sum, fill=class), stat="identity") + labs(y="消费分布", x="15个嫌疑人", title="15个嫌疑人的消费分布") + theme(text=element_text(family="Microsoft YaHei"), axis.title.x=element_text(vjust=0.2), axis.title.y=element_text(vjust=1), plot.title=element_text(vjust=1.2, size=15), legend.title=element_blank(), axis.title=element_text(size=12))
plot(p)

rm(p)