# coding:utf8
import time
# import datetime
import urllib2
import urllib

ISOTIMEFORMAT='%Y-%m-%d %X'

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )
	
inputFile = 'weather.txt'
fr = open(inputFile,'r')

data_head = '[{"name": "weather", "columns": ["time", "sequence_number", "rain"],"points":['
data_tail = ']}]'
data_body = ''
subcount = 0
print person

for line in fr:
	line = line.split(',')
	subcount = subcount + 1
	timestamp = line[0]
	rain = line[1].rstrip('\n')
	rain = float(rain) - 1
	timestamp = time.mktime(time.strptime(timestamp,'%Y-%m-%d %H:%M:%S'))
	timestamp = int(timestamp * 1000)
	data_body += '['+str(timestamp)+', '+str(subcount)+', '+str(rain)+']'
	response = urllib2.urlopen('http://localhost:8086/db/emc/series?u=root&p=root', data_head+data_body+data_tail)
	data_body = ''

print subcount

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )
fr.close()