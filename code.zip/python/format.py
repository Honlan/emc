#!/usr/bin/env python
# coding:utf8
import time

ISOTIMEFORMAT='%Y-%m-%d %X'

inputFile = 'tradeMe.txt'
fr = open(inputFile,'r')

outputFile = "tradeMeDone.txt"
fw = open(outputFile,'w')

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

count = 0

for line in fr:
	line = line.split(",")
	str1 = line[1].strip('\"')
	str2 = line[2].strip('\"')
	str3 = line[3]
	record =  str1 + "," +  str2 + "," + str3
	fw.write(record)
	count = count + 1

#记录当时时间
print time.strftime( ISOTIMEFORMAT, time.localtime() )

print count

fr.close()
fw.close()
